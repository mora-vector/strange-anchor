{ lib, ... }:
{
  options.sandhi = {
    enable = lib.mkEnableOption "the Sandhi substrate policy";
    retainedPackages = lib.mkOption {
      type = lib.types.listOf lib.types.package;
      default = [];
      description = ''Packages or fetched source derivations retained through
        the system closure. Retention lasts only while a retaining generation
        remains rooted. This is not an off-host archive.'';
    };
  };
}
