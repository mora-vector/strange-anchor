{ config, lib, pkgs, ... }:
{
  options.sandhi.gaps = lib.mkOption {
    type = lib.types.attrsOf (lib.types.submodule {
      options = {
        status = lib.mkOption {
          type = lib.types.enum [ "unknown" "withheld" "unsupported" "inapplicable" ];
        };
        reason = lib.mkOption { type = lib.types.str; };
        blocksActivation = lib.mkOption { type = lib.types.bool; default = false; };
      };
    });
    default = {};
    description = "Public unresolved requirements, separate from store retention.";
  };
  config = lib.mkIf config.sandhi.enable {
    assertions = lib.mapAttrsToList (id: gap: {
      assertion = !gap.blocksActivation;
      message = "Sandhi unresolved prerequisite '${id}': ${gap.reason}";
    }) config.sandhi.gaps;
    environment.etc."sandhi/lopa.json".source =
      pkgs.writeText "sandhi-lopa.json" (builtins.toJSON config.sandhi.gaps);
  };
}
