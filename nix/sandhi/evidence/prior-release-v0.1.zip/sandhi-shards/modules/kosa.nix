{ config, lib, ... }:
{
  config = lib.mkIf config.sandhi.enable {
    nix.settings = {
      keep-derivations = true;
      sandbox = true;
      require-sigs = true;
      allow-import-from-derivation = false;
    };
    # A conservative first cut: no scheduled GC. Manual root actions remain
    # administrative operations; this does not prohibit root from deleting.
    nix.gc.automatic = lib.mkDefault false;
    system.extraDependencies = config.sandhi.retainedPackages;
  };
}
