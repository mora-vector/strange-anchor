{
  imports = [ ./sanjna.nix ./kosa.nix ./sandhi.nix ./lopa.nix ./adhikara.nix ];
}
