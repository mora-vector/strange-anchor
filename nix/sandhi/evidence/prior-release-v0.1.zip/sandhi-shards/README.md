# Sandhi shards — convergence draft 0.1

Two design contributions meet here: Sideband's eight-adhyaya derivation model,
and Tessera's four-quarter design with runtime contracts and recovery boundaries.
This bundle is newly authored from the supplied exchange. It does not establish
independent build reproducibility or validate every Sanskrit analogy.

Status: executable Nix module prototype; evaluation-tested, not deployed.

## The synergy

Sideband explains how forms are derived and definitions meet. Tessera asks who
may act, where state lives, and what recovery actually restores. Their useful
intersection is a system with separately inspectable intent, derivation,
evidence, and runtime authority. Sanskrit labels accompany ordinary engineering
contracts; they do not replace them.

| Sideband chapter | Converged treatment | Shard |
| --- | --- | --- |
| Samjna: definitions | Typed, documented public options | modules/sanjna.nix |
| Kosa: store | Conservative GC default and explicit retained package set | modules/kosa.nix |
| Sandhi: joins | Keep documentary definitions with source locations | lib/prakrtibhava.nix; modules/sandhi.nix |
| Anuvrtti: context | Use ordinary module imports and config; do not invent a second evaluator | modules/default.nix |
| Lopa: absence | Separate missing knowledge from retention of actual bytes | modules/lopa.nix |
| Saksya: evidence | Compare reported NAR hashes; withhold canonical status | lib/saksya.nix |
| Siblings: mesh | Inventory without declared leader; host assignment remains unknown | examples/mesh.nix |
| Vyaya: cost | Bound worker memory, lifetime, restart rate; identify missing operational tests | modules/adhikara.nix; this file |

## Corrections carried into code

1. **A recipe is not an archive.** `keep-derivations` retains recipes of live
   outputs; it does not preserve every collected artifact's recipe. Selected
   packages enter the system closure through `system.extraDependencies`.
   They remain protected only while a retaining generation stays rooted.
   Store roots do not protect against device loss. No permanent archive is claimed.
2. **A store pathname is not a reproducibility measurement.** Input-addressed
   outputs can have matching paths and different bytes. The comparator checks
   the declared derivation and sorted output path/NAR-hash pairs.
3. **A custom merge sees surviving definitions.** Nix priority handling occurs
   before the merge. `mkForce` can remove other claims. The regression test makes
   this limitation explicit. Store source documents separately with version history.
4. **Not every difference is an error.** Lists and other option types have their
   own merge rules. Our accumulating type is confined to documentary strings;
   executable options retain their native types and conflict rules.
5. **A fixpoint is not a chronological sutra sequence.** Modules can read the
   merged configuration lazily; recursion still needs care. Overlays may change
   behavior and compatibility, so substitution is not proof of equivalence.
6. **Evaluation need not always precede all builds.** Import-from-derivation can
   cross that boundary. The enabled substrate explicitly disables it.
7. **Names do not establish political equality.** An attribute set can contain
   leaders and ordered relationships. This inventory assigns neither; it cannot
   enforce distributed governance. Crew berths are not assumed to be machines.
8. **Collection is deletion of bytes.** A retained description does not reverse
   an unavailable fetch. Non-reconstructible material needs retained bytes and
   off-host backups. The gap registry is therefore distinct from retention policy.

## What the shards do

`modules/default.nix` imports five modules. Set `sandhi.enable = true` to enable
policy. `sandhi.claims.<subject>` accepts one string per definition and produces
origin-bearing records. The public result is installed at `/etc/sandhi/claims.json`.
Do not use claims to configure credentials, access decisions, ports, or secrets.

` sandhi.gaps ` records unknown, withheld, unsupported, and inapplicable entries.
A `blocksActivation = true` entry becomes a failing NixOS assertion. The public
registry is installed at `/etc/sandhi/lopa.json`. The Mycelium example adds a gap,
not a service or an interpretation of its internals.

` sandhi.workers ` creates local systemd services with dynamic users, private
networks, restricted filesystem access, private state, memory/lifetime limits,
and bounded restart frequency. These are evaluated configuration settings;
namespace behavior has not been exercised in a VM. This is not a VM-strength
boundary for hostile workloads. No network adapter grants are implemented.

Normal NixOS module precedence remains in force. Administrators can override
settings; this is not an unbypassable policy engine. Source claims and gaps are
public store material, not a secrets channel.

## Import into an existing configuration

```nix
{ pkgs, ... }:
{
  imports = [ ./sandhi-shards/modules ];
  sandhi.enable = true;
  sandhi.claims.substrate = "A derivation supplies a recipe, not a backup.";
  sandhi.gaps.archiveRestore = {
    status = "unknown";
    reason = "No restoration drill has been recorded.";
    blocksActivation = true; # Deliberate stop until this prerequisite is resolved.
  };
  sandhi.retainedPackages = [ pkgs.hello ]; # Replace with actual archival inputs.
}
```

Do not import the example into a live system expecting it to boot on its own.
There are deliberately no disks, bootloader, hardware configuration, production
secrets, host assignments, or fleet deployment commands. Keep an existing host's
`system.stateVersion`; the tests' 26.05 value is only for fresh test configurations.

## Attestation contract

`lib.saksya` takes a list of reports shaped as:

```nix
{
  builderId = "builder-a";
  drvPath = "/nix/store/<actual-derivation>.drv";
  outputs = [{ path = "/nix/store/<actual-output>"; narHash = "sha256-<actual-base64>"; }];
}
```

At least two distinct reported builder IDs must agree on the derivation and
all listed outputs. Duplicate IDs, malformed reports, and differing hashes are
held. Success is named `reported-agreement`, and `canonical` is always false.
These fields are comparison data, not signed attestations. A caller must still
authenticate reports, establish independence, confirm that the output inventory
is complete, and apply a release policy. Two builders downloading the same
binary are not two source builds. Two signatures are not two builds either.
A ship-wide release needs closure-wide coverage or an explicitly narrower policy.

The next implementation should produce authenticated manifests from isolated
source builds, compare them before promotion, and preserve disagreements with
logs. No dummy signer or simulated quorum is included.

## Verification and reproducibility

Evaluated with Nix 2.35.2 on x86_64-linux. The flake pins the NixOS 26.05 release
archive at revision b67c7a60c3732edd4b947a7df8af06215851a614 and records its NAR hash
in flake.lock.

- 12 pure evaluation assertions passed: claim origins, rejected claim types,
  executable conflict, priority filtering, report agreement and failure cases.
- 11 NixOS integration evaluation assertions passed: exported registries,
  retention, disabled IFD, blocking gaps, and worker configuration.
- `nix flake check --no-build` passed.

To repeat from the unpacked directory with Nix installed:

```sh
nix --extra-experimental-features 'nix-command flakes' flake check --no-build .
nix --extra-experimental-features 'nix-command flakes' eval --json .#lib.evalTests
nix --extra-experimental-features 'nix-command flakes' eval --json .#lib.integrationTests
```

No system closure was built, VM booted, service started, archive restored,
or second builder commissioned. Passing evaluation does not imply those results.

## Next bounded work

1. Supply a disposable VM host and exercise worker isolation and restart limits.
2. Choose archival sources and an off-host backup target; run a restoration drill.
3. Implement authenticated build reports and a promotion gate.
4. Assign hardware/hosts only after crew berths and compute instances are distinguished.

The first contribution's four quarters remain a review structure. The eight
adhyayas remain a design vocabulary. Executable guarantees reside in the code
and its measured behavior.

## Sources and provenance

- Sideband's eight-adhyaya text: supplied by the user in this conversation.
- Tessera's four-quarter proposal: preceding response in this conversation.
- [Nix configuration settings](https://nix.dev/manual/nix/2.35/command-ref/conf-file.html)
- [GC roots](https://nix.dev/manual/nix/2.35/package-management/garbage-collector-roots.html)
- [Store paths](https://nix.dev/manual/nix/2.35/store/store-path.html)
- [Reproducibility verification](https://nix.dev/manual/nix/2.35/advanced-topics/diff-hook.html)
- [NixOS module types](https://nixos.org/manual/nixos/stable/#sec-option-types)
- [Nixpkgs overlays](https://nixos.org/manual/nixpkgs/stable/#chap-overlays)

The second in-corpus hardware-panel attestation, `anchor.py`, and the Sanskrit
sutra interpretations were not independently inspected in this implementation.
They are not prerequisites for these shards' technical behavior.
